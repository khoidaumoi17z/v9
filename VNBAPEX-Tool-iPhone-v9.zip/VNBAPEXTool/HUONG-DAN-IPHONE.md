# VNBAPEX Tool v9 — phân tích ngữ cảnh và đối chiếu phiên bản

## Nâng cấp v9

- Mở rộng đầu ra mặc định lên 25 ứng viên, tối đa 100; giữ ngưỡng chặt 55 và thăm dò 35. Có thể không có đủ hàm đạt ngưỡng.
- Thêm ứng viên khi kết quả trả về của một hàm có bằng chứng trực tiếp được dùng trong điều kiện C hoặc mẫu nhánh ARM64. Chỉ đi một bước từ điểm trực tiếp; không tiếp tục truyền điểm sang nhiều lớp hàm.
- Ứng viên suy qua điều kiện có điểm tối đa 65 và thấp hơn điểm trực tiếp của hàm gốc ít nhất 12 điểm. Báo cáo ghi riêng `contextDerived` và `contextLinks`. Đây là đầu mối để đọc caller/callee, không khẳng định vai trò chống gian lận được truyền qua lời gọi.
- Thêm dấu vân tay cấu trúc C và ARM64 để đối chiếu khi địa chỉ thay đổi. Với C, chuẩn hóa nhãn sub_HEX/FUN_HEX, biến aN/vN và một số hằng địa chỉ; với ARM64, bỏ displacement của một số lệnh PC-relative và immediate ADD/SUB. Vì việc chuẩn hóa bỏ một phần thông tin, hai hàm khác chức năng vẫn có thể giống nhau.
- Giải mã escape C ASCII, octal và Unicode hợp lệ trước khi tìm dấu hiệu trong literal. Không chạy mã trong dump; không giải mã chuỗi được mã hóa lúc chạy. Literal vẫn bị giới hạn 4.096 ký tự đầu.
- Cải thiện vô hiệu hóa liên hệ biến khi có phép gán kết hợp hoặc thay đổi biến trong điều kiện; nhận thêm cast và một số kiểu thường thấy trong mã giả IDA.

## Khi offset thay đổi giữa hai phiên bản

1. Nạp Mach-O hoặc dump C của **bản cũ**. Nếu có cả hai, dùng các file cùng bản.
2. Bấm **Ghi mốc phiên bản**. App giữ tối đa 2.000 đầu mối có điểm từ 35; mốc nằm trong bộ nhớ của phiên mở app.
3. Bấm **Xóa phiên làm việc** để bỏ dữ liệu đang nạp, rồi nạp **bản mới**. Mốc vẫn được giữ. Nên dùng cùng loại dữ liệu ở hai bản: C với C, Mach-O với Mach-O.
4. Bấm **Đối chiếu bản đang nạp**. Chọn dòng để đọc ứng viên và các phương án khác; bấm **Xuất báo cáo đối chiếu** để giữ báo cáo.
5. Nếu hiện “Mơ hồ” hoặc “Chưa đủ bằng chứng”, đọc lại mã gốc thay vì coi VA đầu tiên là hàm đã tìm đúng. Bấm **Xóa mốc** để bỏ mốc; đóng app hoặc WebView bị khởi động lại cũng làm mất mốc. Muốn làm tiếp ở phiên khác, nạp lại bản cũ và ghi mốc.

Điểm tương đồng và điểm ưu tiên bảo mật là hai đại lượng riêng. Một hàm giống bản cũ chưa chắc giữ cùng hành vi, chưa chứng minh việc sửa hàm có tác dụng tránh ban, và không chứng minh cơ chế bảo mật mới chỉ đổi địa chỉ. Tool không xác định nhà phát triển đã sửa gì chỉ từ một offset.

Đối chiếu giữ 16 giá trị hash nhỏ nhất của các nhóm 4 token/lệnh liên tiếp, xét thêm chuỗi literal, tên lời gọi và tên hàm ổn định. Bản tóm tắt được tạo khi quét toàn bộ phần đọc được, không chỉ phần xem trước. Hash 32-bit không phải chứng minh danh tính; có thể có va chạm. “Có bằng chứng tương đồng” yêu cầu điểm tối thiểu 70, độ giống cấu trúc tối thiểu 0,65, ít nhất 8 hash chung, dấu hiệu bổ sung, cách biệt tối thiểu 12 điểm với ứng viên thứ hai, và không mâu thuẫn địa chỉ. Tên hàm giống nhau đơn thuần không đủ.

Tối đa 1.000 ứng viên tìm kiếm và 50 phép đối chiếu chi tiết mỗi hàm cũ; khi cắt tìm kiếm, kết quả không được tự đánh dấu là được hỗ trợ. Dấu hiệu xuất hiện ở hơn 200 hàm bị bỏ qua; tổng chỉ mục giới hạn 300.000 mục và cache 2.048 hàm. Khi hai hàm cũ cùng khớp một hàm mới, báo mơ hồ. Giao diện hiển thị tối đa 100 dòng đối chiếu, báo cáo JSON chứa toàn bộ mốc đã xét. Các ngưỡng là heuristic chưa được hiệu chuẩn bằng dữ liệu có nhãn.

## Đọc kết quả

Nạp Mach-O ARM64 hoặc dump C. Mặc định phần “Ứng viên kiểm tra bảo mật” chỉ giữ tối đa 25 hàm đạt 55 điểm trở lên. Có thể chọn 3/5/10/25/50/100 hàm, hoặc chế độ thăm dò từ 35 điểm. Không có ứng viên đủ mạnh thì danh sách trống; tool không buộc chọn một hàm bất kỳ. Bảng đầy đủ nằm trong các mục có thể mở rộng.

Điểm 0–100 là trọng số ưu tiên đọc, không phải phần trăm xác suất “antiban”. Chưa có dữ liệu có nhãn hoặc kiểm chứng runtime để hiệu chuẩn xác suất. Bộ phân tích không tương đương IDA/Hex-Rays và không tự chứng minh hiệu quả sửa/hook một vị trí.

- C: xét lời gọi trực tiếp trong if/while/switch và một số mẫu gán cục bộ `v = CheckHook(); if (v)`. Ghi tên kiểm tra và dòng trong thân hàm. Xóa liên hệ khi gặp ghi đè, đổi scope hoặc lời gọi chưa biết; không có CFG/data-flow đầy đủ.
- Mach-O: giữ mẫu ADR hoặc ADRP+ADD kề nhau tới đúng chuỗi đã quét. Bổ sung BL tới mốc hàm metadata rồi CBZ/CBNZ/TBZ/TBNZ trên W0/X0 hoặc CMP W0/X0,#0+B.cond kề nhau. Chỉ giữ nhánh nằm trong section và chuỗi lệnh không vượt mốc hàm tiếp theo.
- Mẫu tên/chuỗi cụ thể, nhiều nhóm dấu hiệu và lời gọi có ngữ cảnh được ưu tiên. Các hàm init/lifecycle, log, hash, memcmp, ptrace/sysctl hoặc chỉ có từ khóa chung bị giảm ưu tiên. Khoảng cách đồ thị đơn thuần không đưa hàm vào danh sách chặt.
- Cấu phần điểm: tên kiểm tra 12; chuỗi cụ thể 18 (chuỗi chung 6); nhóm chức năng 6/nhóm, tối đa 18; XREF chuỗi 26; lời gọi kiểm tra 14; điều kiện C 36; mẫu nhánh ARM64 36 (12 khi đã có điều kiện C); gọi trực tiếp hàm kiểm tra có tên 8. Từ khóa/API chung hoặc lifecycle không có kiểm tra bị chặn ở 30; tiện ích ở 20; thiếu ngữ cảnh cấu trúc ở 45. Ngưỡng 55/35 là lựa chọn heuristic, không được hiệu chuẩn trên tập game thực.
- Hai loại kiểm tra C và ARM64 có thể đến từ các file khác bản. Cùng địa chỉ không chứng minh cùng phiên bản; cần đối chiếu dump gốc và Mach-O tương ứng.

## Địa chỉ

Bảng tách VA, RVA (__TEXT) và file offset toàn file. File offset tính theo ánh xạ Mach-O, có xét slice FAT. Dump đơn lẻ chỉ có nhãn VA; không tự suy ra RVA/file offset khi thiếu binary. Nếu header IDA và tên sub_HEX khác địa chỉ, hàm bị giảm điểm và không xuất hiện trong danh sách chặt. Nếu có Mach-O nhưng nhãn không thuộc section mã, hàm cũng bị giảm điểm.

Dấu “mốc hàm metadata” chỉ cho biết nguồn địa chỉ. Ranh giới hàm chứa điểm gọi/chuỗi suy theo khoảng metadata; không phải kiểm chứng bằng luồng thực thi. Không coi file offset là địa chỉ runtime hoặc RVA.

## Dump từ IDA

IDA/Hex-Rays có mã giả và tham chiếu chéo để đọc cách dùng giá trị. Có thể xuất C listing, rồi nhập vào app. v9 nhận tên sub_HEX/FUN_HEX hoặc tên C đã đổi có header dạng:

```c
//----- (0000000100001000) ----------------------------------------------------
int CheckIntegrity(void) {
    if (CheckHook()) return -1;
    return 0;
}
```

Ví dụ chỉ minh họa cấu trúc, không phải offset game thực. Không gán địa chỉ cho tên riêng thiếu header. Chưa hỗ trợ chữ ký C++/Objective-C phức tạp, lời gọi gián tiếp hay decompiler trên iPhone. Nếu dump bị đổi tên không có header, giữ lại nhãn địa chỉ khi xuất lại.

Tài liệu: https://docs.hex-rays.com/9.0/user-guide/decompiler/interactive/cmd_jump_xref
Xuất C listing: https://python.docs.hex-rays.com/produce_c_file/index.html

## Giới hạn tệp

Giữ nguyên giới hạn 100 MiB = 104.857.600 byte mỗi tệp, kiểm tra cả native và JavaScript. Nhập dump UTF-8/BOM hoặc UTF-16 LE/BE; UTF-16 không BOM chỉ nhận diện từ các byte ASCII đầu. Không tự chuyển dump.cs, ASM, APK, IPA hoặc ELF Android thành dump C/Mach-O.

Xem trước mỗi hàm tối đa 32.768 ký tự, tổng 8.388.608 ký tự; vẫn quét dấu hiệu và điều kiện trên phần đọc tiếp sau xem trước. Tối đa 100.000 hàm, 256 tên lời gọi/hàm, 32 mẫu điều kiện C/hàm, điều kiện dài tối đa 2.048 ký tự, 64 gán cục bộ và 64 đích gọi/hàm khi xếp hạng. Chuỗi literal chỉ quét 4.096 ký tự đầu; chuỗi binary giữ tối đa 4.000 kết quả. Quan hệ gọi tối đa 100.000, XREF chuỗi 20.000, mẫu điều kiện trả về 20.000. Đây là giới hạn bộ quét, không bảo đảm tìm mọi cơ chế bảo mật hoặc iOS cấp đủ RAM cho mọi tệp 100 MiB.

## Tạo IPA bằng GitHub — có thể thao tác trên iPhone

1. Tạo repo GitHub hoặc dùng repo build của bạn. Upload **VNBAPEX-Tool-iPhone-v9.zip** vào gốc repo, giữ đúng tên và giữ nguyên ZIP. Không upload thư mục giải nén thay cho ZIP ở workflow này.
2. Chọn **Add file → Create new file**. Nhập đường dẫn **.github/workflows/build-ipa.yml**. Dán toàn bộ nội dung từ file **VNBAPEX-build-ipa-v9.yml** đi kèm (hoặc `VNBAPEXTool/build-ipa.yml` trong ZIP), rồi commit lên nhánh mặc định, thường là main. Nếu file đã có, thay nội dung.
3. Mở **Actions → Build VNBAPEX Tool v9 → Run workflow → Run workflow**. Workflow dùng macOS runner, chạy kiểm thử, cài XcodeGen, tạo project, build ARM64 và đóng gói IPA chưa ký.
4. Khi tác vụ hoàn tất thành công, mở lần chạy đó. Trong **Artifacts**, tải **VNBAPEX-Tool-v9-unsigned-IPA**. Giải nén artifact để lấy **VNBAPEX-Tool-v9-unsigned.ipa**.
5. IPA này chưa ký, cần ký bằng chứng chỉ/provisioning phù hợp và cài theo cách bạn đang dùng. Workflow không cần chứng chỉ hoặc secrets vì không ký IPA. Sau khi cài, kiểm tra tiêu đề **v9.0**.

Nếu không thấy Run workflow: kiểm tra workflow ở nhánh mặc định, cú pháp YAML và quyền Actions. Nếu build lỗi: mở bước đỏ hoặc tải **VNBAPEX-Tool-v9-build-log** nếu bước build đã tạo log; gửi lỗi đầu tiên hoặc log để đối chiếu. Bước lỗi trước build có thể chưa có artifact log.

Hướng dẫn GitHub chính thức:
https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow
https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts

## Xác minh bản v9

Chạy từ thư mục VNBAPEXTool:

```sh
node Tests/parser.test.cjs
node Tests/relations.test.cjs
node Tests/deep-analysis.test.cjs
node Tests/import-v7.test.cjs
node Tests/focus.test.cjs
node Tests/focus-ui.test.cjs
node Tests/deep-v9.test.cjs
```

Kiểm tra danh sách ngắn, đối chứng log/API chung, dùng biến bị ghi đè, sizeof/điều kiện vô hiệu, dump IDA đổi tên, nhánh ARM64 với thanh ghi sai/clobber, typed offsets, trạng thái nhập/reset và xuất JSON. Test giao diện mô phỏng DOM và cầu nối iOS, không phải Safari/WKWebView thật. Đã chạy kiểm thử trên Linux/Node; chưa build Xcode hoặc chạy iPhone thật trong phiên này. Không có đo lường precision/recall trên tập game có nhãn. APK tham chiếu chỉ được đọc cấu trúc/tài nguyên; chưa khôi phục thuật toán từ lớp bảo vệ.
