(function(){
'use strict';
const el=id=>document.getElementById(id);let ranked=[],shown=[],busy=false,baseline=null,comparison=null;
function draw(){
 shown=OffsetFocus.shortlist(ranked,{mode:el('focusMode').value,limit:el('focusLimit').value});el('focusRows').replaceChildren();
 shown.forEach((f,i)=>{const tr=document.createElement('tr');
  const values=[String(i+1),f.score+'/100 · '+f.tier,f.name,OffsetDesk.hex(f.address.va),OffsetDesk.hex(f.address.rva)||'—',OffsetDesk.hex(f.address.fileOffset)||'—'];
  for(const v of values){const td=document.createElement('td');td.textContent=v;tr.appendChild(td);}
  tr.tabIndex=0;function select(){if(busy)return;window.selectDeskRow(rows[f.rowIndex]);el('focusDetail').textContent=[f.name+' · điểm ưu tiên '+f.score+'/100',f.address.status,...f.components.map(c=>'+'+c.points+' '+c.label),...f.penalties.map(p=>'Giảm ưu tiên: '+p),...f.controlChecks.map(c=>'Điều kiện C: '+c.call+(c.variable?' qua biến '+c.variable:'')+' · dòng trong thân hàm '+c.line),...f.binaryChecks.map(c=>'Điều kiện ARM64: '+c.method+' · gọi '+c.targetName+' tại '+OffsetDesk.hex(c.siteVA)+' · nhánh '+OffsetDesk.hex(c.conditionSiteVA)),...(f.contextLinks||[]).map(c=>'Qua điều kiện: '+c.name+' @ '+OffsetDesk.hex(c.va)+' · nguồn '+c.source+' · điểm trực tiếp '+c.score),...f.directCallees.map(c=>'Gọi tới '+c.name+' @ '+OffsetDesk.hex(c.va)),...(f.bodyTruncated?['Xem trước thân hàm bị rút gọn; dấu hiệu và điều kiện vẫn được quét khi nhập.']:[]),...(f.flowTruncated?['Bộ đọc điều kiện đã chạm giới hạn; kiểm tra dump gốc.']:[]),f.conclusion,'VA/RVA/file offset là ba loại địa chỉ khác nhau. Nhãn dump hoặc ánh xạ cùng địa chỉ chưa chứng minh cùng phiên bản.'].join('\n');}
  tr.onclick=select;tr.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();select();}};el('focusRows').appendChild(tr);
 });
 el('focusSummary').textContent=shown.length?`Giữ ${shown.length}/${ranked.length} đầu mối sau xếp hạng. Điểm là mức ưu tiên đọc; chưa được hiệu chuẩn thành xác suất.`:rows.length?'Chưa có hàm đạt ngưỡng bằng chứng. Có thể đối chiếu dump C cùng bản hoặc mở chế độ thăm dò.':'Nạp Mach-O hoặc dump C để lập danh sách ưu tiên.';
 if(model?.encrypted)el('focusSummary').textContent+=' Mach-O còn mã hóa: bộ quét bỏ qua mã ARM64.';
 el('diffRemember').disabled=busy||!ranked.some(r=>r.score>=35);el('diffCompare').disabled=busy||!baseline||!rows.length;el('diffForget').disabled=busy||!baseline;el('diffExport').disabled=busy||!comparison;
 el('focusExport').disabled=busy||!shown.length;el('focusMode').disabled=el('focusLimit').disabled=busy;
}
function refresh(){comparison=null;el('diffRows').replaceChildren();el('diffSummary').textContent=baseline?'Đã giữ '+baseline.functions.length+' hàm làm mốc. Nạp bản khác rồi bấm Đối chiếu.':'Chưa có mốc. Nạp bản cũ rồi bấm Ghi mốc phiên bản.';ranked=OffsetFocus.rank(rows,model);el('focusDetail').textContent='Chọn một ứng viên để xem lý do và nguồn địa chỉ.';draw();}
window.setFocusBusy=value=>{busy=!!value;draw();};
const previous=window.rebuild;window.rebuild=function(){previous();refresh();};
el('focusMode').onchange=draw;el('focusLimit').onchange=draw;
el('focusExport').onclick=()=>download('VNBAPEX-priority-functions.json',JSON.stringify({tool:'VNBAPEX Tool 9.0',sourceName,dumpName,uuid:model?.uuid||null,base:model?.base??null,mode:el('focusMode').value,minimumScore:el('focusMode').value==='explore'?35:55,limit:Number(el('focusLimit').value),scoreMeaning:OffsetFocus.scoreMeaning,notice:'Not verified anti-cheat or antiban targets. No calibrated probabilities. Dump and binary same-version identity is unverified.',stats:{totalFunctions:rows.length,rankedCandidates:ranked.length,retained:shown.length,dump:window.dumpImportStats||null,binary:model?.callGraph?.stats||null},functions:shown.map(({rowIndex,...f})=>f)},(k,v)=>typeof v==='bigint'?OffsetDesk.hex(v):v,2),'application/json');

el('diffRemember').onclick=()=>{if(busy)return;baseline=OffsetFingerprint.snapshot(rows,model,ranked,{sourceName,dumpName,uuid:model?.uuid||null});comparison=null;el('diffRows').replaceChildren();el('diffSummary').textContent='Đã giữ '+baseline.functions.length+' hàm'+(baseline.truncated?' (đạt giới hạn 2.000)':'')+'. Mốc chỉ được giữ trong phiên mở app này. Nạp bản mới rồi bấm Đối chiếu.';draw();};
el('diffForget').onclick=()=>{if(busy)return;baseline=null;comparison=null;el('diffRows').replaceChildren();el('diffSummary').textContent='Đã xóa mốc đối chiếu.';draw();};
el('diffCompare').onclick=()=>{if(busy||!baseline||!rows.length)return;
 const lock=value=>window.OffsetIOS?window.OffsetIOS.setImportBusy(value):window.setFocusBusy(value);
 lock(true);el('diffSummary').textContent='Đang đối chiếu cấu trúc và bằng chứng…';
 setTimeout(()=>{try{
  comparison=OffsetFingerprint.compare(baseline,rows,model);el('diffRows').replaceChildren();
  for(const m of comparison.matches.slice(0,100)){const c=m.candidates[0],tr=document.createElement('tr');for(const value of [m.oldName+' · '+OffsetDesk.hex(m.oldVA),c?c.name+' · '+OffsetDesk.hex(c.va):'—',c?c.score+'/100':'—',m.status+(m.searchLimited?' (đã giới hạn tìm kiếm)':'')]){const td=document.createElement('td');td.textContent=value;tr.appendChild(td);}
   if(c){tr.tabIndex=0;const pick=()=>{if(busy)return;window.selectDeskRow(rows[c.rowIndex]);el('focusDetail').textContent=[m.status,'Bản cũ: '+m.oldName+' @ '+OffsetDesk.hex(m.oldVA),...m.candidates.map(x=>'Bản mới: '+x.name+' @ '+OffsetDesk.hex(x.va)+' · tương đồng '+x.score+'/100 · cấu trúc '+Math.round(x.structure*100)+'/100'),'Độ cách biệt giữa hai ứng viên đầu: '+m.margin,'Điểm tương đồng không phải điểm bảo mật; không chứng minh chức năng hay tác dụng tránh ban.'].join('\n');};tr.onclick=pick;tr.onkeydown=e=>{if(e.key==='Enter'){pick();}};}el('diffRows').appendChild(tr);
  }
  el('diffSummary').textContent=comparison.stats.supported+' / '+comparison.stats.oldFunctions+' hàm có đối chiếu được hỗ trợ bởi cấu trúc và dấu hiệu khác. Hiển thị tối đa 100 dòng; báo cáo chứa toàn bộ. '+comparison.stats.commonFeaturesSkipped+' dấu hiệu quá phổ biến đã bỏ qua.'+(comparison.stats.candidateLimitReached?' Đã chạm giới hạn tìm kiếm.':'');
 }catch(e){comparison=null;el('diffSummary').textContent='Không đối chiếu được: '+e.message;}finally{lock(false);}},0);
};
el('diffExport').onclick=()=>{if(!comparison||busy)return;download('VNBAPEX-version-comparison.json',JSON.stringify({tool:'VNBAPEX Tool 9.0',baseline:baseline.meta,current:{sourceName,dumpName,uuid:model?.uuid||null},...comparison},(k,v)=>typeof v==='bigint'?OffsetDesk.hex(v):v,2),'application/json');};
refresh();
})();
